import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        char[][] letters = new char[6][6];
        System.out.println(Arrays.deepToString(letters));
        char letter = 'А';
        for (int i = 0; i < letters.length; i++) {
            for (int j = 0; j < letters[i].length; j++) {
                letters[i][j] = letter;
                letter++;
                if (letter > 'Я') break;
                if (letter == 'Ж') {
                    if (j == letters[i].length - 1) {
                        i++;
                        j = 0;
                    } else j++;
                    letters[i][j] = 'Ё';

                }

            }
        }

        System.out.println(Arrays.deepToString(letters));

    }
}