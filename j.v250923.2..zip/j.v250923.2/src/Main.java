public class Main {
    public static void main(String[] args) {
        String[][] letters = {
                {"а", "б", "в", "г", "д", "е", "ё", "ж", "з,","и", "й", "к", "л", "м", "н", "о",
                        "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я"}
        };

        for (char i = 'А'; i <= 'Е';i++) {
            if ( i >= 'А' &&  i <= 'Е');
            System.out.println( i + " - " + i);
        }
        System.out.println(  'Ё' + " - " + 'Ё');
        for (char i = 'Ж'; i <= 'Е'; i++) {
            if ( i >= 'Ж' &&  i <= 'Е');
            System.out.println( i + " - " + i);
        }
        System.out.println(  'Ё' + " - " + 'Ё');
        for (char i = 'Ж';i <= 'Я'; i++) {
            if ( i >= 'Ж' &&  i <= 'Я');
            System.out.println( i+ " - " + i);
        }
    }
}